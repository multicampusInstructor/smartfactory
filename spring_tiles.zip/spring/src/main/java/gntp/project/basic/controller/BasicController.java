package gntp.project.basic.controller;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller("basicController")
public class BasicController {

	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/test.do")
	public ModelAndView testCopnnect(Model model) {
		ModelAndView mav = new ModelAndView();
		String viewName = "result";
		mav.setViewName(viewName);
		
		try {
			Connection con = sqlSession.getConnection();
			if(con!=null) {
				model.addAttribute("result", "mybatis connection");
			} else {
				model.addAttribute("result", "mybatis connection fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mav;
	}
}
