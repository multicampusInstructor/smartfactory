package gntp.project.factory.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gntp.project.factory.utils.CalculatorNextSeq;
import gntp.project.factory.utils.ConnectionManagerV2;
import gntp.project.factory.vo.BoardVO;

@Repository("boardDAO")
public class BoardDAO {
	
	@Autowired
	private SqlSession sqlSession;
	
	public boolean insertItem(BoardVO board) throws SQLException {
		boolean flag = false;
		
		int affectedCount = sqlSession.insert("mapper.board.insertBoard", board);
		if(affectedCount>0) {
			flag = true;
		}

		if(flag) {
			Integer max= sqlSession.selectOne("mapper.board.selectMaxSeq");
			sqlSession.update("mapper.board.updateWriteSeq", max);
			System.out.println("write_seq 생성");
		}

		return flag;
	}
	
	public ArrayList<BoardVO> selectAll() throws SQLException{
		ArrayList<BoardVO> list = null;
		
		list = (ArrayList)sqlSession.selectList("mapper.board.selectAllBoard");
		
		return list;
	}

	public BoardVO selectBoard(String seq) throws SQLException {
		// TODO Auto-generated method stub
		BoardVO board = null;
//		String sql = "select * from board where seq = ?";
//		Connection con = ConnectionManagerV2.getConnection();
//		PreparedStatement pstmt = con.prepareStatement(sql);
//		pstmt.setInt(1,Integer.parseInt(seq.trim()));
//		ResultSet rs = pstmt.executeQuery();
//		while(rs.next()) {
//			String nextSeq = CalculatorNextSeq.getNextSeq(rs.getString(3), rs.getString(7));
//			board = new BoardVO(rs.getInt(1),rs.getInt(2),nextSeq,rs.getString(4),
//					rs.getString(5),rs.getInt(6),rs.getString(7),"user","user",rs.getTimestamp(8));
//		}
//		ConnectionManagerV2.closeConnection(rs, pstmt, con);
		board = sqlSession.selectOne("mapper.board.selectBoardBySeq", Integer.parseInt(seq));
		String nextSeq = CalculatorNextSeq.getNextSeq(board.getCurrentSeq(), board.getNextSeq());
		board.setCurrentSeq(nextSeq);
		
		return board;
	}
	
	public boolean insertReply(BoardVO board) throws SQLException {
		boolean flag = false;
		int affectedCount = sqlSession.insert("mapper.board.insertReply", board);
		if(affectedCount>0) {
			flag = true;
		}
		if(flag) {
			affectedCount = sqlSession.update("mapper.board.updateNextSeq", board);
			if(affectedCount>0) {
				flag = true;
			}
		}

		return flag;
	}
}
