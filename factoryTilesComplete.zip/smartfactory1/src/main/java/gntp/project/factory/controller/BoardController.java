package gntp.project.factory.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import gntp.project.factory.service.BoardService;
import gntp.project.factory.vo.BoardVO;

@Controller("boardController")
@RequestMapping("/board")
public class BoardController {

	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="/viewWriteBoard.do", method=RequestMethod.GET)
	public ModelAndView viewWriteBook(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/board/writeBoard");
		return mav;
	}
	
	@RequestMapping(value="/writeBoard.do", method=RequestMethod.POST)
	public ModelAndView writeBook(@ModelAttribute("info") BoardVO board, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		board.setWriter("user");
		board.setUserId("user");
		boardService.save(board);
		
		mav.setViewName("redirect:/board/list.do");
		return mav;
	}
	
	@RequestMapping(value="/list.do", method=RequestMethod.GET)
	public ModelAndView list(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		ArrayList<BoardVO> list = boardService.readAllBoard();
		mav.addObject("list",list);
		mav.setViewName("/board/list");
		return mav;
	}
	
	@RequestMapping(value="/read.do", method=RequestMethod.GET)
	public ModelAndView read(@RequestParam("seq") String seq, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		BoardVO board = boardService.readBoard(seq);
		mav.addObject("board",board);
		mav.setViewName("/board/read");
		return mav;
	}
	
	@RequestMapping(value="/replyInput.do", method=RequestMethod.POST)
	public ModelAndView replyInput(@ModelAttribute("info") BoardVO board, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		board.setWriter("user");
		board.setUserId("user");
		boardService.insertReply(board);
		mav.addObject("board",board);
		mav.setViewName("redirect:/board/list.do");
		return mav;
	}
	
}
