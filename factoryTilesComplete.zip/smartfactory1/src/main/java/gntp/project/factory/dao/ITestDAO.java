package gntp.project.factory.dao;

import java.sql.SQLException;

import gntp.project.factory.vo.ReplyVO;

public interface ITestDAO {
	public boolean testDB() throws SQLException;
	public ReplyVO selectReply(String seq) throws SQLException;
}
