package gntp.project.factory.service;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gntp.project.factory.dao.BoardDAO;
import gntp.project.factory.vo.BoardVO;

@Service("boardService")
public class BoardService {
	
	@Autowired
	private BoardDAO boardDAO;

	public void save(BoardVO board) {
		// TODO Auto-generated method stub
		try {
			boardDAO.insertItem(board);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<BoardVO> readAllBoard() {
		// TODO Auto-generated method stub
		ArrayList<BoardVO> list = null;
		try {
			list = boardDAO.selectAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public BoardVO readBoard(String seq) {
		// TODO Auto-generated method stub
		BoardVO board = null;
		try {
			board= boardDAO.selectBoard(seq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return board;
	}

	public void insertReply(BoardVO board) {
		// TODO Auto-generated method stub
		try {
			boardDAO.insertReply(board);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
