package lesson.jdbc.day4;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class GisaDAO { //테이블에 대해 CRUD작업
	
	// 조건 조회의 결과를 전달
	public ArrayList<StudentVO> selectQuiz1Data(String code) throws SQLException{ //read작업(select)
		ArrayList<StudentVO> list = null;
		String sql= "select * from gisa where local_code = ?";
		list = new ArrayList<StudentVO>();
		// 컨넥션 정보
		Connection con = ConnectionManager.getConnection();
		// 쿼리보낼 통로 확보
		PreparedStatement pstmt = con.prepareStatement(sql);
		// 쿼리 전송
		pstmt.setString(1,code);
		ResultSet rs = pstmt.executeQuery();
		// 쿼리 처리(테이블형태의 결과)
		StudentVO vo = null;
		while(rs.next()) {
			vo = new StudentVO(rs.getInt(1),rs.getString(2),rs.getInt(3),
					rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),
					rs.getInt(8),rs.getString(9),rs.getString(10),rs.getString(11));
			list.add(vo);
		}
		rs.close();
		pstmt.close();
		con.close();
		
		return list;
	}
	
}
