package lesson.jdbc.day4;

import java.sql.SQLException;
import java.util.ArrayList;

public class QuizSolutionService { //비즈니스로직 클래스
	
	public void solveQuiz1() {
		GisaDAO dao = new GisaDAO();
		try {
			ArrayList<StudentVO> list =
					dao.selectQuiz1Data("B");
			//list 처리 로직(정렬/kor+eng/학번)
			StudentVO vo1 = null;
			StudentVO vo2 = null;
			StudentVO temp = null;
			for(int i=0;i<list.size()-1;i++) {
				for(int j=i+1;j<list.size();j++) {
					vo1 = list.get(i);
					vo2 = list.get(j);
					if(vo1.getQuiz1Data()<vo2.getQuiz1Data()) {
						temp = vo1;
						list.set(i, vo2);
						list.set(j, temp);
					}
				}
			}
			//this.printList(list);
			//System.out.println(list.size());
			System.out.println("정답은 "+list.get(4).getStdNo()+"입니다.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void printList(ArrayList<StudentVO> list) {
		for(StudentVO vo : list) {
			System.out.println(vo);
		}
	}
}
