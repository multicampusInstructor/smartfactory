package lesson.jdbc.day4;

public class TestDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestDB db = new TestDB();
		db.test();
	}
	
	public void test() {
		//로직 클래스를 이용해서 1번 문제 푸는 코드 작성
		QuizSolutionService service = new QuizSolutionService();
		service.solveQuiz1();
		
	}

}
