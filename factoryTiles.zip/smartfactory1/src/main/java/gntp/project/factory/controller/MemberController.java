package gntp.project.factory.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import gntp.project.factory.dao.MemberDAO;
import gntp.project.factory.vo.MemberVO;

@Controller("MemberController")
@RequestMapping("/member")
public class MemberController {
	
	@Autowired
	private MemberDAO memberDAO;
	
	public ModelAndView basic(HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav =new ModelAndView();
		String viewName = this.getViewName(request);

		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/remove.do", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView remove(HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav =new ModelAndView();
		//String viewName = this.getViewName(request);
		String id = request.getParameter("id");
		//MemberDAO dao = new MemberDAO();
		try {
			boolean flag = memberDAO.deleteOne(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.setViewName("redirect:/member/list.do");
		return mav;
	}
	
	@RequestMapping(value="update.do", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView update(HttpServletRequest req, HttpServletResponse response) throws Exception  {
		ModelAndView mav =new ModelAndView();
		//String viewName = this.getViewName(request);
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String pwd = req.getParameter("pwd");
		String email = req.getParameter("email");
		MemberVO member = new MemberVO(id,pwd,name,email,null);
		//업데이트 로직
		//MemberDAO dao = new MemberDAO();
	 	try {
			boolean flag = memberDAO.updateOne(member);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.setViewName("redirect:/member/list.do");
		return mav;
	}
	
	@RequestMapping(value="/read.do", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView read(HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav =new ModelAndView();
		//String viewName = this.getViewName(request);
		String id = request.getParameter("id");
		   //
		   //dao = new MemberDAO();
		   MemberVO member = null;
		   //MemberDAO dao = new MemberDAO();
		try {
			member = memberDAO.selectOne(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//req.setAttribute("member", member);
		mav.addObject("member",member);
		mav.setViewName("/member/"+"viewMemberInfo");
		return mav;
	}
	
	@RequestMapping(value="/join.do", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView join(HttpServletRequest req, HttpServletResponse response) throws Exception  {
		ModelAndView mav =new ModelAndView();
		//String viewName = this.getViewName(request);
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String pwd = req.getParameter("pwd");
		String email = req.getParameter("email");
		MemberVO member = new MemberVO(id,pwd,name,email,null);
		//MemberDAO dao = new MemberDAO();
		try {
			boolean flag = memberDAO.insertOne(member);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.setViewName("redirect:/member/list.do");
		return mav;
	}
	
	@RequestMapping(value="/viewJoinPage.do", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView viewJoinPage(HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav =new ModelAndView();
		String viewName = this.getViewName(request);
		System.out.println(viewName);
		mav.setViewName("/member/join");
		return mav;
	}
	
	@RequestMapping(value="/list.do", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView list(HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav =new ModelAndView();
		String viewName = this.getViewName(request);
		List<MemberVO> list = null;
		//MemberDAO dao = new MemberDAO();
		try {
			list = memberDAO.selectAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//req.setAttribute("list", list);
		mav.addObject("list",list);
		System.out.println("/"+request.getContextPath()+"/member/"+viewName);
		System.out.println(request.getServletPath());
		mav.setViewName("/member"+viewName);
		return mav;
	}
	
	private String getViewName(HttpServletRequest request) throws Exception {
		String contextPath = request.getContextPath();
		String uri = (String) request.getAttribute("javax.servlet.include.request_uri");
		if (uri == null || uri.trim().equals("")) {
			uri = request.getRequestURI();
		}

		// http://localhost:8090/member/listMember.do�� ��û��
		int begin = 0; //
		if (!((contextPath == null) || ("".equals(contextPath)))) {
			begin = contextPath.length(); // ��ü ��û�� �� ���̸� ����
		}

		int end;
		if (uri.indexOf(";") != -1) {
			end = uri.indexOf(";"); // ��û uri�� ';'�� ���� ��� ';'���� ��ġ�� ����
		} else if (uri.indexOf("?") != -1) {
			end = uri.indexOf("?"); // ��û uri�� '?'�� ���� ��� '?' ���� ��ġ�� ����
		} else {
			end = uri.length();
		}

		// http://localhost:8090/member/listMember.do�� ��û�� ���� '.do'�� ������
		// http://localhost:8090/member/listMember�� ���� ��,
		// �ٽ� http://localhost:8090/member/listMember���� �������� ù��° '/' ��ġ�� ����
		// ��, �� ���� listMember�� ���Ѵ�.
		String fileName = uri.substring(begin, end);
		if (fileName.indexOf(".") != -1) {
			fileName = fileName.substring(0, fileName.lastIndexOf(".")); // ��û���� �������� ���� '.'�� ��ġ�� ������,
																			// '.do' �տ������� ���ڿ��� ����
		}
		if (fileName.lastIndexOf("/") != -1) {
			fileName = fileName.substring(fileName.lastIndexOf("/"), fileName.length()); // ��û���� �������� ���� '/'��
																							// ��ġ�� ������, '/'
																							// ���������� ���ڿ��� ����
		}
		return fileName;
	}

}
