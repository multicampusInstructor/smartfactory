package gntp.project.factory.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

public interface ITestController {
	public ModelAndView test(HttpServletRequest request, 
			HttpServletResponse response) throws Exception;
	
	public ModelAndView testFindReply(HttpServletRequest request, 
			HttpServletResponse response) throws Exception;
}
