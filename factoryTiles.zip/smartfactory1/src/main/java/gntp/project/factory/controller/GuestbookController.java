package gntp.project.factory.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import gntp.project.factory.dao.GuestbookDAO;
import gntp.project.factory.vo.GuestbookVO;
import gntp.project.factory.vo.MemberVO;
import gntp.project.factory.vo.ReplyVO;

@Controller("guestbookController")
@RequestMapping("/guestbook")
public class GuestbookController {
	public GuestbookController() {
		System.out.println("contrller start");
	}
	
	@Autowired
	private GuestbookDAO guestbookDAO;
	
	/////////////////////    기본 메소드 형    ////////////////////////////////
	public ModelAndView basic(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = this.getViewName(request);
		
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/viewLogin.do", method=RequestMethod.GET)
	public ModelAndView viewLogin(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = this.getViewName(request);
		
		viewName= "/guestbook/login";
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public ModelAndView login(@RequestParam("userId") String userId,
			@RequestParam("pwd") String pwd, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "redirect:/guestbook/list.do";
		MemberVO vo = guestbookDAO.checkMember(userId, pwd);
		System.out.println(vo);
		if(vo!=null) {
			request.getSession().setAttribute("user", vo);
		}
		mav.setViewName(viewName);
		return mav;
	}
	
	
	@RequestMapping(value="/logout.do", method=RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		request.getSession().invalidate();
		String viewName = "redirect:/guestbook/list.do";
		
		mav.setViewName(viewName);
		return mav;
	}
	
	//////////////////////////////////////////////////////////////////////////
	@RequestMapping(value="/test.do", method=RequestMethod.GET)
	public ModelAndView test(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("welcome");
		return mav;
	}
	
	@RequestMapping(value="/list.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView list(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		ModelAndView mav = new ModelAndView();
		try {
			ArrayList<GuestbookVO> list = guestbookDAO.selectAll();
			mav.addObject("list",list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.setViewName("/guestbook/listBook");
		return mav;
	}
	
	@RequestMapping(value="/viewWriteBook.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView viewWriteBook(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/guestbook/login";
		MemberVO user = (MemberVO)request.getSession().getAttribute("user");
		if(user!=null) {
			viewName = "/guestbook/writeBook";
		}
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/create.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView create(@ModelAttribute("info") GuestbookVO book, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		try {
			boolean flag = guestbookDAO.insertOne(book);
			if(flag) {
				System.out.println("새글이 등록되었습니다.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.setViewName("redirect:/guestbook/list.do");
		return mav;
	}
	
	@RequestMapping(value="/delete.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView delete(@RequestParam("seq") String seq, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		try {
			boolean flag = guestbookDAO.deleteOne(seq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.setViewName("redirect:/guestbook/list.do");
		return mav;
	}
	
	@RequestMapping(value="/read.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView read(@RequestParam Map<String,String> params, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String seq = params.get("seq");
		String token = params.get("token");
		GuestbookVO book = null;
		try {
			book = guestbookDAO.selectOne(seq,token);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.addObject("book",book);
		mav.setViewName("/guestbook/read");
		return mav;
	}
	
	@RequestMapping(value="/writeReply.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView writeReply(@ModelAttribute("info") ReplyVO vo, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		try {
			boolean flag = guestbookDAO.insertReply(vo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("gbseq = "+vo.getGbSeq()+" replyContent = "+vo.getReplyContent());
		mav.setViewName("redirect:/guestbook/read.do?seq="+vo.getGbSeq());
		return mav;
	}
	
	@RequestMapping(value="/viewUpdateBook.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView viewUpdateBook(HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String seq = request.getParameter("gbSeq");
		GuestbookVO book = null;
		try {
			book = guestbookDAO.selectOneForUpdate(seq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mav.addObject("book",book);
		
		mav.setViewName("/guestbook/viewUpdateBook");
		return mav;
	}
	
	@RequestMapping(value="/update.do", method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView update(@ModelAttribute("info") GuestbookVO book, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
			
		try {
			boolean flag = guestbookDAO.updateOne(book);
			
			if(flag) {
				System.out.println("글이 수정되었습니다.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		mav.setViewName("redirect:/guestbook/list.do");
		return mav;
	}
	////////////////////////////////// getView  /////////////////////////////////////
	private String getViewName(HttpServletRequest request) throws Exception {
		String contextPath = request.getContextPath();
		String uri = (String) request.getAttribute("javax.servlet.include.request_uri");
		if (uri == null || uri.trim().equals("")) {
			uri = request.getRequestURI();
		}

		
		int begin = 0; //
		if (!((contextPath == null) || ("".equals(contextPath)))) {
			begin = contextPath.length(); 
		}

		int end;
		if (uri.indexOf(";") != -1) {
			end = uri.indexOf(";");
		} else if (uri.indexOf("?") != -1) {
			end = uri.indexOf("?"); 
		} else {
			end = uri.length();
		}


		String fileName = uri.substring(begin, end);
		if (fileName.indexOf(".") != -1) {
			fileName = fileName.substring(0, fileName.lastIndexOf(".")); 
		}
		if (fileName.lastIndexOf("/") != -1) {
			fileName = fileName.substring(fileName.lastIndexOf("/"), fileName.length()); 
		}
		return fileName;
	}
}
