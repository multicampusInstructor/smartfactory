package gntp.project.factory.service;

import gntp.project.factory.vo.ReplyVO;

public interface ITestService {
	public boolean testService();
	public ReplyVO testFind(String seq);
}
