package gntp.project.factory.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import gntp.project.factory.service.TestService;
import gntp.project.factory.vo.ReplyVO;

@Controller("testController")
@RequestMapping("/test")
public class TestController implements ITestController {
	
	@Autowired
	private TestService testService;

	@Override
	@RequestMapping(value="/test.do", method=RequestMethod.GET)
	public ModelAndView test(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		ModelAndView mav = new ModelAndView();
		String viewName = "error";
		boolean flag = testService.testService();
		if(flag) {
			viewName = "welcome";
		}
		mav.setViewName(viewName);
		return mav;
	}

	@Override
	@RequestMapping(value="/testFindReply.do", method=RequestMethod.GET)
	public ModelAndView testFindReply(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		ModelAndView mav = new ModelAndView();
		String seq = request.getParameter("seq");
		String viewName = "error";
		ReplyVO vo = testService.testFind(seq);
		if(vo!=null) {
			viewName = "result";
			mav.addObject("reply",vo);
		}
		mav.setViewName(viewName);
		return mav;
	}
	
}
