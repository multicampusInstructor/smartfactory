package lesson.jdbc.day3;

import java.sql.SQLException;

import lesson.jdbc.day2.GisaDAO;

public class GisaQuizService {
	
	//1번 문제 2중 정렬하고 5번째 학생의 학번은?
	public int getFifthStdNo() throws SQLException {
		int answer = 0;
		String sql = "select std_no "
				+ "from gisa "
				+ "where local_code = 'B' "
				+ "order by (kor+eng) desc, std_no asc limit 4, 1;";
		GisaDAO dao = new GisaDAO();
		answer = dao.selectQuery1(sql);
		return answer;
	}
	
	//2번 문제 풀이 - 지역코드가 B인 학생의 kor+eng점수가 가장 큰 점수는?
	public int getMaxScore() throws SQLException {
		//DB를 이용해서 처리하는 것을 알고(이해하고) 있어야 한다.
		//따라서 처리로직이 없다.
		int answer = 0;
		String sql = "select max(kor+eng) from gisa where local_code = 'B'";
		GisaDAO dao = new GisaDAO();
		answer = dao.selectQuery2(sql);
		return answer;
	}
	
	//3번문제 조건에 맞는 점수의 누적합
	public int getSumOfScore() throws SQLException {
		int answer = 0;
		String sql = "select sum(total)+sum(case acc_code"
				+ "	when 'A' then 5"
				+ "	when 'B' then 15"
				+ "	when 'C' then 20"
				+ "	else 0 "
				+ " end) as total "
				+ " from gisa "
				+ " where (eng+math) >= 120;";
		//System.out.println(sql);
		GisaDAO dao = new GisaDAO();
		answer = dao.selectQuery3(sql);
		return answer;
	}
	
	//4번 문제 조건에 맞는 학생의 수 누적
	public int getSumOfCount() throws SQLException {
		int answer = 0;
		String sql = "select count(*)"
				+ " from gisa"
				+ " where (acc_code = 'A' or acc_code = 'B') "
				+ " and (kor + (case local_code"
				+ "	when 'A' then 5"
				+ "	when 'B' then 10"
				+ "	when 'C' then 15"
				+ "	else 0"
				+ " end)) >= 50;";
		GisaDAO dao = new GisaDAO();
		answer = dao.selectQuery4(sql);
		return answer;
	}
	
}
