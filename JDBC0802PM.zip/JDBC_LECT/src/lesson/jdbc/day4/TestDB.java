package lesson.jdbc.day4;

import java.sql.Date;
import java.sql.Timestamp;

public class TestDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestDB db = new TestDB();
		db.test();
	}
	public void testDate() {
		//sql에서 사용하는 Date에 관련된 객체 만들기
		Date date  = new Date(System.currentTimeMillis());//데이터베이스 Date형
		Timestamp stamp = new Timestamp(System.currentTimeMillis());//데이터베이스 Timestamp형 호환
		
	}
	public void test() {
		//로직 클래스를 이용해서 1번 문제 푸는 코드 작성
		QuizSolutionService service = new QuizSolutionService();
		service.solveQuiz1V2();
		service.solveQuiz3();
		service.solveQuiz4();
		
	}

}
