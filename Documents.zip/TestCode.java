package lesson.extra;

public class TestCode {
	//인스턴스변수, 정적변수대하여 예제코드를 작성하시오.
	private int age;
	public static String firstName;
	public void test3() {
		
	}
}
