package lesson.extra;

public class TestMain {
	private int age;
	public static String firstName = "Kim";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(this.age);
//		System.out.println(TestMain.firstName);
//		TestMain.firstName = "Lee";
//		test1();
//		TestMain.test1();
		TestMain tm = new TestMain();
//		tm.test1();
		tm.test3();
	}
	public void test2() {
		System.out.println(this.age);
	}
	public static void test1() {
		TestMain tm=new TestMain();
		System.out.println(tm.age);
		System.out.println(TestMain.firstName);
		//System.out.println(this.firstName);
	}
	public void test4() {
		Person kim = new Student();
	}
	public void test3() {
		//for , while, do - while
		//if
		
		int a = 10;
		if (a>10) {
			System.out.println("a는 10보다 크다.");
		} else {
			System.out.println("a는 10보다 크지 않다.");
		}
		
		String result = a > 10 ? "a는 10보다 크다." : "a는 10보다 크지 않다.";
		int value =  a > 10 ? a*10 : a / 10;
		System.out.println(value);
	}

}
