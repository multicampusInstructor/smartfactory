package lesson.extra;

public abstract class Person {
	private int age;
	private String name;
	public abstract void eat();
	public void sleep() {
		//기본 행동
	}
}
