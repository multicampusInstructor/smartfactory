package lesson.extra;

public class Student extends Person{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}

}
