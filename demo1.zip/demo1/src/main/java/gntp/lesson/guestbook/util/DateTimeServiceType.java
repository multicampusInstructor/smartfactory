package gntp.lesson.guestbook.util;

public enum DateTimeServiceType {
	DATE_ONLY,TIME_ONLY,DATE_TIME
}
