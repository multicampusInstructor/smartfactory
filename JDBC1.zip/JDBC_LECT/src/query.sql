-- 정보 처리기사 1,3,4번 문제를 푸는 쿼리생성하고
-- 3개의 클래스에 비어있는 메소드를 구현하는 코드 생성
select std_no
from gisa
where local_code = 'B'
order by (kor+eng) desc, std_no asc limit 4, 1;

select sum(total)+sum(case acc_code
	when 'A' then 5
	when 'B' then 15
	when 'C' then 20
	else 0
end) as total
from gisa
where (eng+math) >= 120;