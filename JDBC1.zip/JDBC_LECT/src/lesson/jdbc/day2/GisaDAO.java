package lesson.jdbc.day2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class GisaDAO {
	
	public int selectQuery1(String query) throws SQLException {
		int result = 0;
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			result = rs.getInt(1);
		}
		/////////// 주의 확인 /////////////
		rs.close();
		//////////////////////////////////
		pstmt.close();
		con.close();
		return result;
	}
	
	public int selectQuery3(String query) throws SQLException {
		int result = 0;
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			result = rs.getInt(1);
		}
		/////////// 주의 확인 /////////////
		rs.close();
		//////////////////////////////////
		pstmt.close();
		con.close();
		return result;
	}
	
	public int selectQuery4(String query) throws SQLException {
		int result = 0;
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			result = rs.getInt(1);
		}
		/////////// 주의 확인 /////////////
		rs.close();
		//////////////////////////////////
		pstmt.close();
		con.close();
		return result;
	}
	
	public int selectQuery2(String query) throws SQLException {
		int result = 0;
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement(query);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			result = rs.getInt(1);
		}
		/////////// 주의 확인 /////////////
		rs.close();
		//////////////////////////////////
		pstmt.close();
		con.close();
		return result;
	}
	
	public boolean deleteData() throws SQLException {
		boolean flag = false;
		//컨낵션 취득
		Connection con = ConnectionManager.getConnection();
		//쿼리 작성
		String sql = "delete from gisa";
		//쿼리 전송 통로 작성
		Statement stmt = con.createStatement();
		
		//쿼리 전송
		int affectedCount = stmt.executeUpdate(sql);
		//결과 처리
		if(affectedCount>0) {
			flag = true;
		}	
		//연결된 통로 모두 닫고
		stmt.close();
		con.close();
		return flag;
	}
	public boolean deleteData(int stdNo) throws SQLException {
		boolean flag = false;
		//컨낵션 취득
		Connection con = ConnectionManager.getConnection();
		//쿼리 작성
		String sql = "delete from gisa where std_no = "+stdNo;
		//쿼리 전송 통로 작성
		Statement stmt = con.createStatement();
		
		//쿼리 전송
		int affectedCount = stmt.executeUpdate(sql);
		//결과 처리
		if(affectedCount>0) {
			flag = true;
		}	
		//연결된 통로 모두 닫고
		stmt.close();
		con.close();
		return flag;
	}
	
	public boolean insertDataV2(ArrayList<StudentVO> list) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into gisa values (?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		//StudentVO vo = null;
		int affectedCount = 0;
		for(StudentVO vo : list) {
			//vo = list.get(0);
			pstmt.setInt(1, vo.getStdNo());
			pstmt.setString(2, vo.getEmail());
			pstmt.setInt(3, vo.getKor());
			pstmt.setInt(4, vo.getEng());
			pstmt.setInt(5, vo.getMath());
			pstmt.setInt(6, vo.getSci());
			pstmt.setInt(7, vo.getHist());
			pstmt.setInt(8, vo.getTotal());
			pstmt.setString(9, vo.getMgrCode());
			pstmt.setString(10, vo.getAccCode());
			pstmt.setString(11, vo.getLocCode());
			affectedCount += pstmt.executeUpdate();
		}
		if(affectedCount>0) {
			flag = true;
		}
		pstmt.close();
		con.close();
		return flag;
	}
	
	
	
	public boolean insertData(ArrayList<StudentVO> list) throws SQLException {
		boolean flag = false;
		int affectedCount = 0;
		// 컨넥션 객체 가져오기
		Connection con= ConnectionManager.getConnection();
		Statement stmt = null;
		for(StudentVO vo : list) {
			String sql = "insert into gisa values ("+vo.getStdNo()+",'"+vo.getEmail()+"',"+vo.getKor()+","+vo.getEng()+","
					+ vo.getMath()+","+vo.getSci()+","+vo.getHist()+","+vo.getTotal()+",'"+vo.getMgrCode()+"','"+vo.getAccCode()+"','"+vo.getLocCode()+"')";
			
			// 삽입 준비하기
			stmt = con.createStatement();
			// 삽입하기
			affectedCount += stmt.executeUpdate(sql);
		}
		// 연결종료 //////////////
		stmt.close();
		con.close();
		////////////////////////
		// 삽입결과 확인하고 flag에 세팅
		if(affectedCount > 0) {
			flag = true;
		}
		return flag;
	}
	
	public boolean insertData(StudentVO vo) throws SQLException {
		//data를 gisa테이블에 삽입
		boolean flag = false;
		//990001,addx, 17, 29, 16, 49, 43,154,C,A,C
		// 테이블 삽입 쿼리 작성
		String sql = "insert into gisa values ("+vo.getStdNo()+",'"+vo.getEmail()+"',"+vo.getKor()+","+vo.getEng()+","
				+ vo.getMath()+","+vo.getSci()+","+vo.getHist()+","+vo.getTotal()+",'"+vo.getMgrCode()+"','"+vo.getAccCode()+"','"+vo.getLocCode()+"')";
		// 컨넥션 객체 가져오기
		Connection con= ConnectionManager.getConnection();
		// 삽입 준비하기
		Statement stmt = con.createStatement();
		// 삽입하기
		int affectedCount = stmt.executeUpdate(sql);
		// 연결종료 //////////////
		con.close();
		////////////////////////
		// 삽입결과 확인하고 flag에 세팅
		if(affectedCount > 0) {
			flag = true;
		}
		return flag;
	}
}
