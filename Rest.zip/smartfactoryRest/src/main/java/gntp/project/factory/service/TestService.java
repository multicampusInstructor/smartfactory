package gntp.project.factory.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gntp.project.factory.dao.TestDAO;

@Service("testService")
public class TestService {

	@Autowired
	private TestDAO testDAO;
	
	public boolean testService() {
		boolean flag = false;
		try {
			flag = testDAO.testDB();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
}
